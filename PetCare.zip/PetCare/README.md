# PetCare (MVP)

Android · Kotlin · Jetpack Compose · Room · WorkManager · CameraX + ML Kit · Yandex MapKit · OpenAI-compatible LLM.
Tested toolchain target: Android Studio Quail 4 | 2026.1.4 (AGP 9.4.0, Gradle 9.6.0, Kotlin 2.3.21, KSP 2.3.10).

## Setup
1. File ▸ Open ▸ select this folder. If Studio complains about the missing wrapper jar, run `gradle wrapper --gradle-version 9.6.0` once.
2. Put keys into `local.properties` (see `local.properties.example`):
   - `YANDEX_MAPKIT_KEY` — from developer.tech.yandex.ru (MapKit mobile SDK)
   - `LLM_*` — any OpenAI-compatible `/chat/completions` endpoint (YandexGPT, OpenAI, GigaChat gateway…)
3. Sync, run on a device (camera/location need real hardware or emulator virtual sensors).
4. Library versions were picked conservatively; if Studio suggests newer ones, accept them.

## Screens
| Tab | What's there |
|---|---|
| Главная | pet profile (photo, age, last weight), SOS → map, "+ Взвесить", upcoming-events countdowns |
| Корм | CameraX frame → ML Kit OCR → editable text → LLM verdict (🟢🟡🔴) using the pet profile in the system prompt |
| Медкарта | tabs: vaccinations/treatments (+reminder via WorkManager at 10:00), weight chart, diary |
| Карта | MapKit, user position, "Ветеринарная клиника" search, "open now" filter, call + route |

## Known limitations
- ML Kit on-device OCR supports Latin/Chinese/Japanese/Korean/Devanagari — **not Cyrillic**. Russian labels need another `TextRecognizerEngine` (e.g. Yandex Vision OCR); the text-confirmation step is already in place for corrections.
- The LLM key is read from BuildConfig, so it ships inside the APK. Fine for a prototype; for release, proxy via your own backend.
- Map code is the least-verified part (MapKit API surface varies by version). "Open now" parses `workingHours.state.text` — see `toClinic()`.
- UI strings are hardcoded in Russian (move to `strings.xml` when localizing).
