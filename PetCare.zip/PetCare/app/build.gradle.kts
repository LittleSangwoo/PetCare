import java.util.Properties

plugins {
    alias(libs.plugins.android.application)
    alias(libs.plugins.kotlin.compose)
    alias(libs.plugins.kotlin.serialization)
    alias(libs.plugins.ksp)
}

// Secrets live in local.properties (not committed). See local.properties.example
val secrets = Properties().apply {
    rootProject.file("local.properties").takeIf { it.exists() }?.inputStream()?.use { load(it) }
}
fun secret(key: String, default: String = "") = secrets.getProperty(key, default)

android {
    namespace = "com.petcare.app"
    compileSdk = 36

    defaultConfig {
        applicationId = "com.petcare.app"
        minSdk = 26
        targetSdk = 36
        versionCode = 1
        versionName = "0.1.0"

        buildConfigField("String", "LLM_BASE_URL", "\"${secret("LLM_BASE_URL", "https://llm.api.cloud.yandex.net/v1")}\"")
        buildConfigField("String", "LLM_API_KEY", "\"${secret("LLM_API_KEY")}\"")
        buildConfigField("String", "LLM_AUTH_SCHEME", "\"${secret("LLM_AUTH_SCHEME", "Bearer")}\"")
        buildConfigField("String", "LLM_MODEL", "\"${secret("LLM_MODEL", "gpt-4o-mini")}\"")
        buildConfigField("String", "YANDEX_MAPKIT_KEY", "\"${secret("YANDEX_MAPKIT_KEY")}\"")
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
}

dependencies {
    implementation(libs.androidx.core.ktx)
    implementation(libs.androidx.activity.compose)
    implementation(platform(libs.androidx.compose.bom))
    implementation(libs.androidx.compose.ui)
    implementation(libs.androidx.compose.material3)
    implementation(libs.androidx.compose.tooling.preview)
    implementation(libs.androidx.lifecycle.viewmodel.compose)
    implementation(libs.androidx.lifecycle.runtime.compose)
    implementation(libs.androidx.navigation.compose)

    implementation(libs.androidx.room.runtime)
    implementation(libs.androidx.room.ktx)
    ksp(libs.androidx.room.compiler)

    implementation(libs.androidx.work.runtime.ktx)

    implementation(libs.androidx.camera.core)
    implementation(libs.androidx.camera.camera2)
    implementation(libs.androidx.camera.lifecycle)
    implementation(libs.androidx.camera.view)
    implementation(libs.mlkit.text.recognition)

    implementation(libs.kotlinx.coroutines.android)
    implementation(libs.kotlinx.coroutines.play.services)
    implementation(libs.kotlinx.serialization.json)
    implementation(libs.okhttp)
    implementation(libs.coil.compose)
    implementation(libs.yandex.mapkit)
}
