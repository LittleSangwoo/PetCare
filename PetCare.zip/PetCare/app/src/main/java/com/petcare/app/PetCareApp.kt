package com.petcare.app

import android.app.Application
import androidx.room.Room
import com.petcare.app.data.AppDb
import com.yandex.mapkit.MapKitFactory

class PetCareApp : Application() {
    val db: AppDb by lazy { Room.databaseBuilder(this, AppDb::class.java, "petcare.db").build() }

    override fun onCreate() {
        super.onCreate()
        if (BuildConfig.YANDEX_MAPKIT_KEY.isNotBlank()) {
            MapKitFactory.setLocale("ru_RU")
            MapKitFactory.setApiKey(BuildConfig.YANDEX_MAPKIT_KEY)
        }
    }
}
