package com.petcare.app.data

import androidx.room.*
import kotlinx.coroutines.flow.Flow

enum class RecordType(val label: String) {
    COMPLEX("Комплексная вакцина"),
    RABIES("Бешенство"),
    TICKS("От клещей"),
    WORMS("От гельминтов")
}

enum class RemindInterval(val label: String, val months: Long) {
    M1("1 мес.", 1), M3("3 мес.", 3), M6("6 мес.", 6), Y1("1 год", 12)
}

@Entity(tableName = "pet")
data class Pet(
    @PrimaryKey val id: Int = 1,
    val name: String = "",
    val birthEpochDay: Long? = null,
    val neutered: Boolean = false,
    val conditions: String = "",
    val photoPath: String? = null
)

@Entity(tableName = "health_record")
data class HealthRecord(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val type: String,
    val drug: String,
    val dateEpochDay: Long,
    val nextEpochDay: Long?
)

@Entity(tableName = "weight")
data class WeightEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val epochDay: Long,
    val kg: Float
)

@Entity(tableName = "note")
data class DiaryNote(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val epochDay: Long,
    val text: String
)

@Dao
interface PetDao {
    @Query("SELECT * FROM pet WHERE id = 1") fun pet(): Flow<Pet?>
    @Upsert suspend fun upsertPet(pet: Pet)

    @Query("SELECT * FROM health_record ORDER BY dateEpochDay DESC") fun records(): Flow<List<HealthRecord>>
    @Insert suspend fun insertRecord(r: HealthRecord): Long
    @Delete suspend fun deleteRecord(r: HealthRecord)

    @Query("SELECT * FROM weight ORDER BY epochDay ASC, id ASC") fun weights(): Flow<List<WeightEntry>>
    @Insert suspend fun insertWeight(w: WeightEntry)
    @Delete suspend fun deleteWeight(w: WeightEntry)

    @Query("SELECT * FROM note ORDER BY epochDay DESC, id DESC") fun notes(): Flow<List<DiaryNote>>
    @Insert suspend fun insertNote(n: DiaryNote)
    @Delete suspend fun deleteNote(n: DiaryNote)
}

@Database(
    entities = [Pet::class, HealthRecord::class, WeightEntry::class, DiaryNote::class],
    version = 1,
    exportSchema = false
)
abstract class AppDb : RoomDatabase() {
    abstract fun dao(): PetDao
}
