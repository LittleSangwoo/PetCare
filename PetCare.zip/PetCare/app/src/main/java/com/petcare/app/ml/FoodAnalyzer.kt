package com.petcare.app.ml

import com.petcare.app.BuildConfig
import com.petcare.app.data.Pet
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import kotlinx.serialization.json.*
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.time.LocalDate
import java.time.Period
import java.util.concurrent.TimeUnit

enum class Verdict(val emoji: String, val label: String) {
    GREEN("🟢", "Отлично"),
    YELLOW("🟡", "С осторожностью"),
    RED("🔴", "Не рекомендуется")
}

data class FoodResult(val verdict: Verdict, val summary: String)

class FoodAnalyzer {
    private val client = OkHttpClient.Builder()
        .callTimeout(60, TimeUnit.SECONDS)
        .build()
    private val json = Json { ignoreUnknownKeys = true }

    suspend fun analyze(pet: Pet?, ingredients: String): FoodResult = withContext(Dispatchers.IO) {
        check(BuildConfig.LLM_API_KEY.isNotBlank()) { "Не задан LLM_API_KEY в local.properties" }

        val body = buildJsonObject {
            put("model", BuildConfig.LLM_MODEL)
            put("temperature", 0.2)
            putJsonArray("messages") {
                addJsonObject { put("role", "system"); put("content", systemPrompt(pet)) }
                addJsonObject { put("role", "user"); put("content", "Состав с упаковки: $ingredients") }
            }
        }.toString()

        val req = Request.Builder()
            .url(BuildConfig.LLM_BASE_URL.trimEnd('/') + "/chat/completions")
            .header("Authorization", "${BuildConfig.LLM_AUTH_SCHEME} ${BuildConfig.LLM_API_KEY}")
            .post(body.toRequestBody("application/json".toMediaType()))
            .build()

        client.newCall(req).execute().use { resp ->
            val text = resp.body?.string().orEmpty()
            check(resp.isSuccessful) { "LLM вернул ${resp.code}: ${text.take(200)}" }
            val content = json.parseToJsonElement(text).jsonObject["choices"]!!
                .jsonArray[0].jsonObject["message"]!!.jsonObject["content"]!!.jsonPrimitive.content
            parse(content)
        }
    }

    private fun systemPrompt(pet: Pet?): String {
        val age = pet?.birthEpochDay?.let {
            val p = Period.between(LocalDate.ofEpochDay(it), LocalDate.now())
            if (p.years > 0) "${p.years} лет" else "${p.months} мес."
        } ?: "возраст не указан"
        val context = buildString {
            append("Имя: ").append(pet?.name?.ifBlank { "не указано" } ?: "не указано")
            append(", ").append(age)
            append(", ").append(if (pet?.neutered == true) "кастрирован/стерилизована" else "не кастрирован")
            append(". Хронические заболевания: ")
            append(pet?.conditions?.ifBlank { "не указаны" } ?: "не указаны")
        }
        return """
            Ты профессиональный ветеринар-диетолог. Проанализируй состав корма для кота.
            Контекст питомца: $context.
            Задача: оцени качество ингредиентов. Укажи плюсы. Укажи минусы. Дай итоговый вердикт: подходит ли этот корм конкретно для этого кота, учитывая его статус (кастрация/заболевания). Отвечай кратко, тезисно.
            Текст состава распознан с фото и может содержать ошибки OCR — учитывай это.
            Формат ответа — СТРОГО один JSON без markdown и пояснений:
            {"verdict":"GREEN|YELLOW|RED","summary":"Плюсы: ...\nМинусы: ...\nИтог: ..."}
            GREEN = отлично подходит, YELLOW = с осторожностью, RED = не рекомендуется.
        """.trimIndent()
    }

    private fun parse(raw: String): FoodResult {
        val cleaned = raw.trim().removePrefix("```json").removePrefix("```").removeSuffix("```").trim()
        return runCatching {
            val o = json.parseToJsonElement(cleaned).jsonObject
            val v = runCatching { Verdict.valueOf(o["verdict"]!!.jsonPrimitive.content.uppercase()) }
                .getOrDefault(Verdict.YELLOW)
            FoodResult(v, o["summary"]!!.jsonPrimitive.content)
        }.getOrElse { FoodResult(Verdict.YELLOW, raw.trim()) } // model ignored JSON format: show as-is
    }
}
