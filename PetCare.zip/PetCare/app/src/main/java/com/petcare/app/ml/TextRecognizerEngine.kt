package com.petcare.app.ml

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.tasks.await

/** Swap this implementation if you need Cyrillic (see README). */
interface TextRecognizerEngine {
    suspend fun recognize(bitmap: Bitmap): String
}

class MlKitRecognizer : TextRecognizerEngine {
    private val client = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    override suspend fun recognize(bitmap: Bitmap): String =
        client.process(InputImage.fromBitmap(bitmap, 0)).await().text
}
