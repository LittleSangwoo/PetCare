package com.petcare.app.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil3.compose.AsyncImage
import com.petcare.app.data.Pet
import com.petcare.app.data.RecordType
import java.io.File

@Composable
fun DashboardScreen(vm: MainViewModel, onSos: () -> Unit) {
    val pet by vm.pet.collectAsStateWithLifecycle()
    val records by vm.records.collectAsStateWithLifecycle()
    val weights by vm.weights.collectAsStateWithLifecycle()
    var showWeight by remember { mutableStateOf(false) }
    var showEdit by remember { mutableStateOf(false) }

    // latest scheduled "next" date per procedure type
    val upcoming = remember(records) {
        records.filter { it.nextEpochDay != null }
            .groupBy { it.type }
            .map { (_, list) -> list.maxBy { it.nextEpochDay!! } }
            .sortedBy { it.nextEpochDay }
    }

    Column(
        Modifier.fillMaxSize().verticalScroll(rememberScrollState()).statusBarsPadding().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        Card(Modifier.fillMaxWidth().clickable { showEdit = true }) {
            Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(16.dp)) {
                Box(
                    Modifier.size(88.dp).clip(CircleShape).background(MaterialTheme.colorScheme.surfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    val path = pet?.photoPath
                    if (path != null) AsyncImage(File(path), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop)
                    else Text("🐱", fontSize = 40.sp)
                }
                Column {
                    Text(pet?.name?.ifBlank { null } ?: "Добавьте питомца", style = MaterialTheme.typography.headlineSmall)
                    Text("Возраст: ${ageText(pet?.birthEpochDay)}")
                    Text("Вес: ${weights.lastOrNull()?.let { "${it.kg} кг" } ?: "—"}")
                }
            }
        }

        Button(
            onClick = onSos,
            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFD32F2F), contentColor = Color.White),
            modifier = Modifier.fillMaxWidth().height(64.dp)
        ) { Text("🚑  SOS — ветклиники рядом", fontSize = 18.sp) }

        OutlinedButton(onClick = { showWeight = true }, modifier = Modifier.fillMaxWidth()) { Text("+ Взвесить") }

        Text("Ближайшие события", style = MaterialTheme.typography.titleMedium)
        if (upcoming.isEmpty()) {
            Text("Нет запланированных событий. Добавьте прививку в Медкарте и включите напоминание.",
                color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
        upcoming.forEach { r ->
            val type = RecordType.entries.firstOrNull { it.name == r.type }
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.padding(16.dp).fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column(Modifier.weight(1f)) {
                        Text(type?.label ?: r.type, style = MaterialTheme.typography.titleSmall)
                        if (r.drug.isNotBlank()) Text(r.drug, style = MaterialTheme.typography.bodySmall)
                    }
                    Text(countdown(r.nextEpochDay!!), style = MaterialTheme.typography.titleSmall)
                }
            }
        }
    }

    if (showWeight) WeightSheet(onDismiss = { showWeight = false }, onSave = vm::addWeight)
    if (showEdit) EditPetDialog(pet ?: Pet(), vm, onDismiss = { showEdit = false })
}

@Composable
private fun EditPetDialog(pet: Pet, vm: MainViewModel, onDismiss: () -> Unit) {
    var name by remember { mutableStateOf(pet.name) }
    var birth by remember { mutableStateOf(pet.birthEpochDay) }
    var neutered by remember { mutableStateOf(pet.neutered) }
    var conditions by remember { mutableStateOf(pet.conditions) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.PickVisualMedia()) { uri -> uri?.let(vm::savePhoto) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Профиль питомца") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedButton(onClick = { picker.launch(PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)) }) { Text("Выбрать фото") }
                OutlinedTextField(name, { name = it }, label = { Text("Имя") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                DatePickerField("Дата рождения", birth, { birth = it })
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(neutered, { neutered = it })
                    Spacer(Modifier.width(8.dp))
                    Text("Кастрирован / стерилизована")
                }
                OutlinedTextField(conditions, { conditions = it }, label = { Text("Хронические заболевания") },
                    supportingText = { Text("Например: склонность к МКБ. Используется при анализе корма.") },
                    modifier = Modifier.fillMaxWidth())
            }
        },
        confirmButton = {
            TextButton(onClick = {
                // re-read pet photo path from DB-backed state to avoid overwriting a freshly picked photo
                vm.savePet(vm.pet.value?.copy(name = name.trim(), birthEpochDay = birth, neutered = neutered, conditions = conditions.trim())
                    ?: pet.copy(name = name.trim(), birthEpochDay = birth, neutered = neutered, conditions = conditions.trim()))
                onDismiss()
            }) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}
