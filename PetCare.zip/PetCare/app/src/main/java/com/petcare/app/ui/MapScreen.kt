package com.petcare.app.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.core.graphics.drawable.toBitmap
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import com.petcare.app.BuildConfig
import com.petcare.app.R
import com.yandex.mapkit.Animation
import com.yandex.mapkit.MapKitFactory
import com.yandex.mapkit.geometry.BoundingBox
import com.yandex.mapkit.geometry.Geometry
import com.yandex.mapkit.geometry.Point
import com.yandex.mapkit.location.Location
import com.yandex.mapkit.location.LocationListener
import com.yandex.mapkit.location.LocationStatus
import com.yandex.mapkit.map.CameraPosition
import com.yandex.mapkit.map.MapObjectTapListener
import com.yandex.mapkit.mapview.MapView
import com.yandex.mapkit.search.*
import com.yandex.mapkit.search.Session
import com.yandex.runtime.Error
import com.yandex.runtime.image.ImageProvider

data class Clinic(
    val name: String,
    val address: String,
    val phone: String?,
    val point: Point,
    val openNow: Boolean
)

@Composable
fun MapScreen() {
    if (BuildConfig.YANDEX_MAPKIT_KEY.isBlank()) {
        Box(Modifier.fillMaxSize().padding(24.dp), Alignment.Center) {
            Text("Добавьте YANDEX_MAPKIT_KEY в local.properties, чтобы включить карту.")
        }
        return
    }

    val ctx = LocalContext.current
    var hasLocation by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED)
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { hasLocation = it }
    LaunchedEffect(Unit) { if (!hasLocation) launcher.launch(Manifest.permission.ACCESS_FINE_LOCATION) }
    if (!hasLocation) {
        Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
            Text("Для поиска ближайших клиник нужен доступ к геопозиции.")
            Spacer(Modifier.height(12.dp))
            Button(onClick = { launcher.launch(Manifest.permission.ACCESS_FINE_LOCATION) }) { Text("Разрешить") }
        }
        return
    }

    val mapView = remember { MapView(ctx) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val obs = LifecycleEventObserver { _, e ->
            when (e) {
                Lifecycle.Event.ON_START -> { MapKitFactory.getInstance().onStart(); mapView.onStart() }
                Lifecycle.Event.ON_STOP -> { mapView.onStop(); MapKitFactory.getInstance().onStop() }
                else -> Unit
            }
        }
        owner.lifecycle.addObserver(obs)
        onDispose { owner.lifecycle.removeObserver(obs) }
    }

    // MapKit holds only weak references to listeners/sessions — keep them alive here.
    val keepAlive = remember { mutableListOf<Any>() }
    var clinics by remember { mutableStateOf(emptyList<Clinic>()) }
    var onlyOpen by remember { mutableStateOf(false) }
    var selected by remember { mutableStateOf<Clinic?>(null) }
    var status by remember { mutableStateOf("Определяем местоположение…") }
    val visible = remember(clinics, onlyOpen) { if (onlyOpen) clinics.filter { it.openNow } else clinics }

    val searchManager = remember { SearchFactory.getInstance().createSearchManager(SearchManagerType.COMBINED) }
    val markers = remember { mapView.mapWindow.map.mapObjects.addCollection() }
    val pin = remember { ContextCompat.getDrawable(ctx, R.drawable.ic_vet)!!.toBitmap(96, 96).let(ImageProvider::fromBitmap) }
    val tapListener = remember { MapObjectTapListener { obj, _ -> selected = obj.userData as? Clinic; true } }

    LaunchedEffect(Unit) {
        MapKitFactory.getInstance().createUserLocationLayer(mapView.mapWindow).also { keepAlive += it }.isVisible = true

        val listener = object : LocationListener {
            override fun onLocationUpdated(location: Location) {
                val p = location.position
                mapView.mapWindow.map.move(CameraPosition(p, 13f, 0f, 0f), Animation(Animation.Type.SMOOTH, 0.5f), null)
                status = "Ищем клиники…"
                val d = 0.06 // ~6 km box around the user
                val geometry = Geometry.fromBoundingBox(
                    BoundingBox(Point(p.latitude - d, p.longitude - d), Point(p.latitude + d, p.longitude + d))
                )
                val options = SearchOptions().apply { searchTypes = SearchType.BIZ.value; resultPageSize = 40 }
                val session = searchManager.submit("Ветеринарная клиника", geometry, options, object : Session.SearchListener {
                    override fun onSearchResponse(response: Response) {
                        clinics = response.collection.children.mapNotNull { it.obj?.toClinic() }
                        status = if (clinics.isEmpty()) "Клиники не найдены" else "Найдено: ${clinics.size}"
                    }
                    override fun onSearchError(error: Error) { status = "Ошибка поиска" }
                })
                keepAlive += session
            }
            override fun onLocationStatusUpdated(status: LocationStatus) {}
        }
        keepAlive += listener
        MapKitFactory.getInstance().createLocationManager().requestSingleUpdate(listener)
    }

    LaunchedEffect(visible) {
        markers.clear()
        visible.forEach { c ->
            val pm = markers.addPlacemark(c.point, pin)
            pm.userData = c
            pm.addTapListener(tapListener)
        }
    }

    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(status, Modifier.weight(1f), style = MaterialTheme.typography.bodyMedium)
            Text("Открыто сейчас")
            Spacer(Modifier.width(8.dp))
            Switch(onlyOpen, { onlyOpen = it })
        }
        AndroidView(factory = { mapView }, modifier = Modifier.fillMaxWidth().weight(1f))

        selected?.let { c ->
            Card(Modifier.fillMaxWidth().padding(8.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text(c.name, style = MaterialTheme.typography.titleMedium)
                    Text(c.address, style = MaterialTheme.typography.bodySmall)
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        if (c.phone != null) Button(onClick = {
                            ctx.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${c.phone}")))
                        }) { Text("📞 ${c.phone}") }
                        OutlinedButton(onClick = {
                            // Opens the Yandex Maps app if installed, otherwise the browser; route starts at current position.
                            val uri = Uri.parse("https://yandex.ru/maps/?rtext=~${c.point.latitude},${c.point.longitude}&rtt=auto")
                            ctx.startActivity(Intent(Intent.ACTION_VIEW, uri))
                        }) { Text("Построить маршрут") }
                    }
                }
            }
        }

        LazyColumn(Modifier.fillMaxWidth().heightIn(max = 180.dp)) {
            items(visible, key = { "${it.name}${it.point.latitude}${it.point.longitude}" }) { c ->
                ListItem(
                    headlineContent = { Text(c.name) },
                    supportingContent = { Text(c.address) },
                    trailingContent = { if (c.openNow) Text("открыто") },
                    modifier = Modifier.clickable {
                        selected = c
                        mapView.mapWindow.map.move(CameraPosition(c.point, 15f, 0f, 0f), Animation(Animation.Type.SMOOTH, 0.4f), null)
                    }
                )
            }
        }
    }
}

private fun com.yandex.mapkit.GeoObject.toClinic(): Clinic? {
    val point = geometry.firstOrNull()?.point ?: return null
    val meta = metadataContainer.getItem(BusinessObjectMetadata::class.java)
    // VERIFY against your MapKit version: relies on the localized working-state text ("Открыто до 21:00", "Круглосуточно").
    val state = meta?.workingHours?.state?.text.orEmpty()
    val open = state.startsWith("Открыто", ignoreCase = true) || state.contains("круглосуточно", ignoreCase = true)
    return Clinic(
        name = name ?: meta?.name ?: "Ветклиника",
        address = meta?.address?.formattedAddress ?: descriptionText.orEmpty(),
        phone = meta?.phones?.firstOrNull()?.formattedNumber,
        point = point,
        openNow = open
    )
}
