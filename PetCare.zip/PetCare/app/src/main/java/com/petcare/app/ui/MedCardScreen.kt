package com.petcare.app.ui

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.petcare.app.data.RecordType
import com.petcare.app.data.RemindInterval
import java.time.LocalDate

@Composable
fun MedCardScreen(vm: MainViewModel) {
    var tab by remember { mutableIntStateOf(0) }
    val titles = listOf("Прививки", "Вес", "Хроника")
    Column(Modifier.fillMaxSize().statusBarsPadding()) {
        TabRow(selectedTabIndex = tab) {
            titles.forEachIndexed { i, t -> Tab(selected = tab == i, onClick = { tab = i }, text = { Text(t) }) }
        }
        when (tab) {
            0 -> RecordsTab(vm)
            1 -> WeightTab(vm)
            else -> NotesTab(vm)
        }
    }
}

@Composable
private fun RecordsTab(vm: MainViewModel) {
    val records by vm.records.collectAsStateWithLifecycle()
    var adding by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Button(onClick = { adding = true }, modifier = Modifier.fillMaxWidth()) { Text("Добавить") }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(records, key = { it.id }) { r ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(RecordType.entries.firstOrNull { it.name == r.type }?.label ?: r.type, style = MaterialTheme.typography.titleSmall)
                            if (r.drug.isNotBlank()) Text(r.drug)
                            Text("Дата: ${fmtDate(r.dateEpochDay)}", style = MaterialTheme.typography.bodySmall)
                            r.nextEpochDay?.let { Text("Следующая: ${fmtDate(it)} (${countdown(it)})", style = MaterialTheme.typography.bodySmall) }
                        }
                        IconButton(onClick = { vm.deleteRecord(r) }) { Icon(Icons.Default.Delete, "Удалить") }
                    }
                }
            }
        }
    }
    if (adding) AddRecordDialog(onDismiss = { adding = false }) { type, drug, date, interval ->
        vm.addRecord(type, drug, date, interval)
    }
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun AddRecordDialog(onDismiss: () -> Unit, onSave: (RecordType, String, Long, RemindInterval?) -> Unit) {
    var type by remember { mutableStateOf(RecordType.COMPLEX) }
    var drug by remember { mutableStateOf("") }
    var date by remember { mutableLongStateOf(LocalDate.now().toEpochDay()) }
    var remind by remember { mutableStateOf(false) }
    var interval by remember { mutableStateOf(RemindInterval.Y1) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Новая запись") },
        text = {
            Column(Modifier.verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    RecordType.entries.forEach { t ->
                        FilterChip(selected = type == t, onClick = { type = t }, label = { Text(t.label) })
                    }
                }
                OutlinedTextField(drug, { drug = it }, label = { Text("Название препарата") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                DatePickerField("Дата", date, { date = it })
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(remind, { remind = it })
                    Text("Напомнить о следующей")
                }
                if (remind) FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    RemindInterval.entries.forEach { i ->
                        FilterChip(selected = interval == i, onClick = { interval = i }, label = { Text("через ${i.label}") })
                    }
                }
            }
        },
        confirmButton = {
            TextButton(onClick = { onSave(type, drug.trim(), date, if (remind) interval else null); onDismiss() }) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}

@Composable
private fun WeightTab(vm: MainViewModel) {
    val weights by vm.weights.collectAsStateWithLifecycle()
    var adding by remember { mutableStateOf(false) }
    val line = MaterialTheme.colorScheme.primary
    val grid = MaterialTheme.colorScheme.outlineVariant

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Button(onClick = { adding = true }, modifier = Modifier.fillMaxWidth()) { Text("+ Взвесить") }
        if (weights.size < 2) {
            Text("Добавьте минимум два измерения, чтобы увидеть график.", color = MaterialTheme.colorScheme.onSurfaceVariant)
        } else {
            val min = weights.minOf { it.kg }; val max = weights.maxOf { it.kg }
            Text("Мин. ${min} кг · Макс. ${max} кг", style = MaterialTheme.typography.bodySmall)
            Canvas(Modifier.fillMaxWidth().height(200.dp)) {
                val pad = 12.dp.toPx()
                val w = size.width - 2 * pad; val h = size.height - 2 * pad
                val span = (max - min).takeIf { it > 0f } ?: 1f
                repeat(4) { i ->
                    val y = pad + h * i / 3f
                    drawLine(grid, Offset(pad, y), Offset(pad + w, y), 1.dp.toPx())
                }
                val pts = weights.mapIndexed { i, e ->
                    Offset(pad + w * i / (weights.size - 1), pad + h * (1f - (e.kg - min) / span))
                }
                val path = Path().apply { pts.forEachIndexed { i, p -> if (i == 0) moveTo(p.x, p.y) else lineTo(p.x, p.y) } }
                drawPath(path, line, style = Stroke(3.dp.toPx()))
                pts.forEach { drawCircle(line, 4.dp.toPx(), it) }
            }
        }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(4.dp)) {
            items(weights.asReversed(), key = { it.id }) { e ->
                Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                    Text("${fmtDate(e.epochDay)} — ${e.kg} кг", Modifier.weight(1f))
                    IconButton(onClick = { vm.deleteWeight(e) }) { Icon(Icons.Default.Delete, "Удалить") }
                }
            }
        }
    }
    if (adding) WeightSheet(onDismiss = { adding = false }, onSave = vm::addWeight)
}

@Composable
private fun NotesTab(vm: MainViewModel) {
    val notes by vm.notes.collectAsStateWithLifecycle()
    var text by remember { mutableStateOf("") }
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        OutlinedTextField(text, { text = it }, label = { Text("Заметка (например: «Вялый»)") }, modifier = Modifier.fillMaxWidth())
        Button(
            onClick = { vm.addNote(text.trim()); text = "" },
            enabled = text.isNotBlank(),
            modifier = Modifier.fillMaxWidth()
        ) { Text("Добавить") }
        LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(notes, key = { it.id }) { n ->
                Card(Modifier.fillMaxWidth()) {
                    Row(Modifier.padding(start = 16.dp, top = 8.dp, bottom = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(fmtDate(n.epochDay), style = MaterialTheme.typography.labelMedium)
                            Text(n.text)
                        }
                        IconButton(onClick = { vm.deleteNote(n) }) { Icon(Icons.Default.Delete, "Удалить") }
                    }
                }
            }
        }
    }
}
