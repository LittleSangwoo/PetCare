package com.petcare.app.ui

import android.Manifest
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Matrix
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import com.petcare.app.ml.Verdict

@Composable
fun ScannerScreen(main: MainViewModel, vm: ScannerViewModel = viewModel()) {
    val ui by vm.ui.collectAsStateWithLifecycle()
    val pet by main.pet.collectAsStateWithLifecycle()

    Box(Modifier.fillMaxSize()) {
        when (val s = ui) {
            ScanUi.Camera -> CameraStage(onBitmap = vm::onPhoto)
            ScanUi.Busy -> Box(Modifier.fillMaxSize(), Alignment.Center) {
                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator(); Spacer(Modifier.height(12.dp)); Text("Обрабатываем…")
                }
            }
            is ScanUi.Confirm -> {
                var text by remember(s.text) { mutableStateOf(s.text) }
                Column(Modifier.fillMaxSize().statusBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text("Проверьте текст состава", style = MaterialTheme.typography.titleLarge)
                    Text("Удалите лишнее и исправьте ошибки распознавания.", style = MaterialTheme.typography.bodyMedium)
                    OutlinedTextField(text, { text = it }, modifier = Modifier.fillMaxWidth().weight(1f))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedButton(onClick = vm::reset, modifier = Modifier.weight(1f)) { Text("Переснять") }
                        Button(onClick = { vm.analyze(pet, text) }, enabled = text.isNotBlank(), modifier = Modifier.weight(1f)) { Text("Анализировать") }
                    }
                }
            }
            is ScanUi.Result -> {
                val v = s.result.verdict
                val color = when (v) {
                    Verdict.GREEN -> Color(0xFF2E7D32); Verdict.YELLOW -> Color(0xFFF9A825); Verdict.RED -> Color(0xFFC62828)
                }
                Column(Modifier.fillMaxSize().verticalScroll(rememberScrollState()).statusBarsPadding().padding(16.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
                    Card(Modifier.fillMaxWidth(), border = BorderStroke(2.dp, color)) {
                        Text("${v.emoji} ${v.label}", style = MaterialTheme.typography.headlineSmall, modifier = Modifier.padding(16.dp))
                    }
                    Text(s.result.summary, style = MaterialTheme.typography.bodyLarge)
                    Text("Ответ ИИ носит справочный характер и не заменяет консультацию ветеринара.",
                        style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Button(onClick = vm::reset, modifier = Modifier.fillMaxWidth()) { Text("Сканировать ещё") }
                }
            }
            is ScanUi.Failure -> Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
                Text(s.message, color = MaterialTheme.colorScheme.error)
                Spacer(Modifier.height(16.dp))
                if (s.text != null) Button(onClick = { vm.toConfirm(s.text) }) { Text("Назад к тексту") }
                else Button(onClick = vm::reset) { Text("Попробовать снова") }
            }
        }
    }
}

@Composable
private fun CameraStage(onBitmap: (Bitmap) -> Unit) {
    val ctx = LocalContext.current
    var granted by remember {
        mutableStateOf(ContextCompat.checkSelfPermission(ctx, Manifest.permission.CAMERA) == PackageManager.PERMISSION_GRANTED)
    }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted = it }
    LaunchedEffect(Unit) { if (!granted) launcher.launch(Manifest.permission.CAMERA) }

    if (!granted) {
        Column(Modifier.fillMaxSize().padding(24.dp), Arrangement.Center, Alignment.CenterHorizontally) {
            Text("Для сканирования состава нужен доступ к камере.")
            Spacer(Modifier.height(12.dp))
            Button(onClick = { launcher.launch(Manifest.permission.CAMERA) }) { Text("Разрешить") }
        }
        return
    }

    val owner = LocalLifecycleOwner.current
    val imageCapture = remember { ImageCapture.Builder().setCaptureMode(ImageCapture.CAPTURE_MODE_MAXIMIZE_QUALITY).build() }

    Box(Modifier.fillMaxSize()) {
        AndroidView(
            factory = { c ->
                PreviewView(c).also { pv ->
                    val future = ProcessCameraProvider.getInstance(c)
                    future.addListener({
                        val provider = future.get()
                        val preview = Preview.Builder().build().also { it.surfaceProvider = pv.surfaceProvider }
                        provider.unbindAll()
                        provider.bindToLifecycle(owner, CameraSelector.DEFAULT_BACK_CAMERA, preview, imageCapture)
                    }, ContextCompat.getMainExecutor(c))
                }
            },
            modifier = Modifier.fillMaxSize()
        )
        Box(
            Modifier.align(Alignment.Center).fillMaxWidth(0.9f).fillMaxHeight(0.3f)
                .border(2.dp, Color.White, RoundedCornerShape(12.dp))
        )
        Text("Наведите рамку на состав", color = Color.White, modifier = Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(16.dp))
        Button(
            onClick = {
                imageCapture.takePicture(ContextCompat.getMainExecutor(ctx), object : ImageCapture.OnImageCapturedCallback() {
                    override fun onCaptureSuccess(image: ImageProxy) {
                        val bmp = image.toBitmap()
                        val rot = image.imageInfo.rotationDegrees
                        image.close()
                        onBitmap(cropToFrame(bmp, rot))
                    }
                    override fun onError(exception: ImageCaptureException) { /* user can just tap again */ }
                })
            },
            modifier = Modifier.align(Alignment.BottomCenter).padding(24.dp)
        ) { Text("Сфотографировать") }
    }
}

/** Rotates to upright and crops to the guide frame (slightly generous: 90% width, 34% height, centered). */
private fun cropToFrame(src: Bitmap, rotation: Int): Bitmap {
    val upright = if (rotation == 0) src else
        Bitmap.createBitmap(src, 0, 0, src.width, src.height, Matrix().apply { postRotate(rotation.toFloat()) }, true)
    val w = (upright.width * 0.9f).toInt()
    val h = (upright.height * 0.34f).toInt()
    return Bitmap.createBitmap(upright, (upright.width - w) / 2, (upright.height - h) / 2, w, h)
}
