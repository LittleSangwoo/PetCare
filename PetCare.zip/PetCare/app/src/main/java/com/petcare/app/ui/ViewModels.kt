package com.petcare.app.ui

import android.app.Application
import android.graphics.Bitmap
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.petcare.app.PetCareApp
import com.petcare.app.data.*
import com.petcare.app.ml.FoodAnalyzer
import com.petcare.app.ml.FoodResult
import com.petcare.app.ml.MlKitRecognizer
import com.petcare.app.ml.TextRecognizerEngine
import com.petcare.app.work.Reminders
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.io.File
import java.time.LocalDate

class MainViewModel(app: Application) : AndroidViewModel(app) {
    private val dao = (app as PetCareApp).db.dao()
    private fun <T> Flow<T>.state(initial: T) =
        stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), initial)

    val pet = dao.pet().state(null)
    val records = dao.records().state(emptyList())
    val weights = dao.weights().state(emptyList())
    val notes = dao.notes().state(emptyList())

    fun savePet(p: Pet) = viewModelScope.launch { dao.upsertPet(p) }

    fun savePhoto(uri: Uri) = viewModelScope.launch(Dispatchers.IO) {
        val ctx = getApplication<Application>()
        val f = File(ctx.filesDir, "pet_${System.currentTimeMillis()}.jpg")
        ctx.contentResolver.openInputStream(uri)?.use { i -> f.outputStream().use { i.copyTo(it) } }
        val cur = dao.pet().first() ?: Pet()
        cur.photoPath?.let { File(it).delete() }
        dao.upsertPet(cur.copy(photoPath = f.absolutePath))
    }

    fun addWeight(kg: Float) = viewModelScope.launch {
        dao.insertWeight(WeightEntry(epochDay = LocalDate.now().toEpochDay(), kg = kg))
    }
    fun deleteWeight(w: WeightEntry) = viewModelScope.launch { dao.deleteWeight(w) }

    fun addRecord(type: RecordType, drug: String, epochDay: Long, interval: RemindInterval?) =
        viewModelScope.launch {
            val next = interval?.let { LocalDate.ofEpochDay(epochDay).plusMonths(it.months).toEpochDay() }
            val id = dao.insertRecord(HealthRecord(type = type.name, drug = drug, dateEpochDay = epochDay, nextEpochDay = next))
            if (next != null) {
                val label = if (drug.isBlank()) type.label else "${type.label}: $drug"
                Reminders.schedule(getApplication(), id, label, next)
            }
        }

    fun deleteRecord(r: HealthRecord) = viewModelScope.launch {
        dao.deleteRecord(r)
        Reminders.cancel(getApplication(), r.id)
    }

    fun addNote(text: String) = viewModelScope.launch {
        dao.insertNote(DiaryNote(epochDay = LocalDate.now().toEpochDay(), text = text))
    }
    fun deleteNote(n: DiaryNote) = viewModelScope.launch { dao.deleteNote(n) }
}

sealed interface ScanUi {
    data object Camera : ScanUi
    data object Busy : ScanUi
    data class Confirm(val text: String) : ScanUi
    data class Result(val result: FoodResult) : ScanUi
    data class Failure(val message: String, val text: String?) : ScanUi
}

class ScannerViewModel(app: Application) : AndroidViewModel(app) {
    private val recognizer: TextRecognizerEngine = MlKitRecognizer()
    private val analyzer = FoodAnalyzer()
    private val _ui = MutableStateFlow<ScanUi>(ScanUi.Camera)
    val ui = _ui.asStateFlow()

    fun onPhoto(bitmap: Bitmap) {
        _ui.value = ScanUi.Busy
        viewModelScope.launch {
            _ui.value = runCatching { recognizer.recognize(bitmap) }.fold(
                onSuccess = {
                    if (it.isBlank()) ScanUi.Failure("Текст на фото не найден. Попробуйте ещё раз.", null)
                    else ScanUi.Confirm(it.trim())
                },
                onFailure = { ScanUi.Failure("Ошибка распознавания: ${it.message}", null) }
            )
        }
    }

    fun analyze(pet: Pet?, text: String) {
        _ui.value = ScanUi.Busy
        viewModelScope.launch {
            _ui.value = runCatching { analyzer.analyze(pet, text) }.fold(
                onSuccess = { ScanUi.Result(it) },
                onFailure = { ScanUi.Failure(it.message ?: "Не удалось получить анализ", text) }
            )
        }
    }

    fun toConfirm(text: String) { _ui.value = ScanUi.Confirm(text) }
    fun reset() { _ui.value = ScanUi.Camera }
}
