package com.petcare.app.work

import android.Manifest
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import androidx.core.app.NotificationCompat
import androidx.core.content.ContextCompat
import androidx.work.*
import com.petcare.app.MainActivity
import java.time.Duration
import java.time.LocalDate
import java.time.LocalDateTime
import java.util.concurrent.TimeUnit

class ReminderWorker(ctx: Context, params: WorkerParameters) : CoroutineWorker(ctx, params) {
    override suspend fun doWork(): Result {
        val text = inputData.getString("text") ?: return Result.success()
        val id = inputData.getLong("id", 0L).toInt()
        val nm = applicationContext.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Напоминания", NotificationManager.IMPORTANCE_DEFAULT)
        )
        val granted = android.os.Build.VERSION.SDK_INT < 33 ||
            ContextCompat.checkSelfPermission(applicationContext, Manifest.permission.POST_NOTIFICATIONS) ==
            PackageManager.PERMISSION_GRANTED
        if (!granted) return Result.success()

        val pi = PendingIntent.getActivity(
            applicationContext, 0,
            Intent(applicationContext, MainActivity::class.java),
            PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT
        )
        val n = NotificationCompat.Builder(applicationContext, CHANNEL)
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle("PetCare: пора обработать питомца")
            .setContentText(text)
            .setContentIntent(pi)
            .setAutoCancel(true)
            .build()
        nm.notify(id, n)
        return Result.success()
    }

    companion object { const val CHANNEL = "reminders" }
}

object Reminders {
    /** Fires at 10:00 local time on [epochDay]. Past dates are ignored. */
    fun schedule(ctx: Context, recordId: Long, text: String, epochDay: Long) {
        val trigger = LocalDate.ofEpochDay(epochDay).atTime(10, 0)
        val delay = Duration.between(LocalDateTime.now(), trigger).toMillis()
        if (delay <= 0) return
        val req = OneTimeWorkRequestBuilder<ReminderWorker>()
            .setInitialDelay(delay, TimeUnit.MILLISECONDS)
            .setInputData(workDataOf("text" to text, "id" to recordId))
            .build()
        WorkManager.getInstance(ctx)
            .enqueueUniqueWork("reminder_$recordId", ExistingWorkPolicy.REPLACE, req)
    }

    fun cancel(ctx: Context, recordId: Long) {
        WorkManager.getInstance(ctx).cancelUniqueWork("reminder_$recordId")
    }
}
