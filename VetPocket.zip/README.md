# VetPocket (PetBase)

Нативное Android-приложение на Kotlin + Jetpack Compose, реализованное строго
по технической документации проекта. Архитектура: MVVM, навигация через
Scaffold + NavHost и Bottom Navigation Bar, БД — Room.

## Структура

```
app/src/main/java/com/vetpocket/app/
├── MainActivity.kt              — точка входа, Scaffold + NavHost
├── VetPocketApp.kt              — Application, инициализация Room и репозитория
├── navigation/NavGraph.kt       — 4 экрана и маршруты
├── ui/
│   ├── dashboard/    — Экран 1: Главная (шапка, события, SOS, "+ Взвесить")
│   ├── scanner/      — Экран 2: Анализатор корма (CameraX + ML Kit + LLM)
│   ├── health/       — Экран 3: Медкарта (3 вкладки, график Vico)
│   ├── map/          — Экран 4: Карта (Yandex MapKit, фильтр "Открыто сейчас")
│   ├── components/   — общие элементы (BottomNavBar, SosButton)
│   └── theme/        — Material3 тема
└── data/
    ├── db/           — Room: Entities, DAO, AppDatabase
    ├── repository/   — PetRepository — единая точка доступа к данным
    ├── llm/          — PromptBuilder (System Prompt из профиля) + LlmClient
    └── reminder/     — AlarmManager: ReminderScheduler, ReminderReceiver, BootReceiver
```

## Перед сборкой

1. Откройте проект в Android Studio (Koala/Ladybug или новее).
2. В `app/build.gradle.kts` пропишите реальные ключи:
   - `YANDEX_MAPKIT_API_KEY` — ключ Yandex MapKit SDK (получить на
     https://developer.tech.yandex.ru/).
   - В `ScannerScreen.kt` замените `apiKey = "YOUR_API_KEY"` на реальный ключ
     Anthropic API (лучше передавать через `local.properties` /
     `BuildConfig`, а не хранить в коде).
3. Выполните Gradle Sync — все зависимости (Compose, Room, CameraX, ML Kit,
   Vico, Yandex MapKit, OkHttp) подтянутся из объявленных репозиториев.
4. Соберите и запустите на устройстве/эмуляторе с Google Play Services
   (нужен для ML Kit) — API 26+.

## Что уже реализовано

- Room-схема данных согласно разделу 4 документации (PetProfileEntity,
  WeightRecordEntity, MedicalEventEntity, DiaryNoteEntity).
- Все 4 экрана с описанным в документации функционалом.
- Формирование System Prompt на основе профиля питомца перед обращением к LLM.
- Локальное распознавание текста через ML Kit (без сети) с ручным
  подтверждением пользователем перед анализом.
- Планирование локальных напоминаний через AlarmManager с восстановлением
  после перезагрузки устройства (BootReceiver).

## Что нужно донастроить вручную

- Реальные API-ключи (Yandex MapKit, LLM).
- Экран добавления/редактирования профиля питомца (в документации не описан
  подробно — сейчас профиль создаётся программно через `PetRepository.savePet`,
  UI для этого можно добавить по тому же паттерну, что и `DashboardScreen`).
- Реальный статус "открыто сейчас" для клиник — в коде это заглушка
  (`isOpenNow = true`), полноценно нужно парсить `BusinessObjectMetadata.workingHours`
  из ответа Yandex Search API.
