package com.vetpocket.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.runtime.Composable
import androidx.navigation.compose.rememberNavController
import com.vetpocket.app.navigation.VetPocketNavHost
import com.vetpocket.app.ui.components.VetPocketBottomBar
import com.vetpocket.app.ui.theme.VetPocketTheme
import com.yandex.mapkit.MapKitFactory

/**
 * Единственная Activity приложения. Навигация между четырьмя экранами
 * реализована через Scaffold + NavHost (Архитектура, раздел 1).
 */
class MainActivity : ComponentActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Ключ Yandex MapKit должен быть установлен до первого обращения к карте
        MapKitFactory.setApiKey(BuildConfig.YANDEX_MAPKIT_API_KEY)

        setContent {
            VetPocketTheme {
                VetPocketRoot()
            }
        }
    }

    override fun onStart() {
        super.onStart()
        MapKitFactory.getInstance().onStart()
    }

    override fun onStop() {
        MapKitFactory.getInstance().onStop()
        super.onStop()
    }
}

@Composable
private fun VetPocketRoot() {
    val navController = rememberNavController()
    Scaffold(
        bottomBar = { VetPocketBottomBar(navController) }
    ) { padding ->
        androidx.compose.foundation.layout.Box(androidx.compose.ui.Modifier.padding(padding)) {
            VetPocketNavHost(navController)
        }
    }
}
