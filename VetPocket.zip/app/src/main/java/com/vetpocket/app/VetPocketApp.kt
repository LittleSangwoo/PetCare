package com.vetpocket.app

import android.app.Application
import com.vetpocket.app.data.db.AppDatabase
import com.vetpocket.app.data.repository.PetRepository

/** Application-класс: единая точка создания БД и репозитория (простой сервис-локатор). */
class VetPocketApp : Application() {

    lateinit var repository: PetRepository
        private set

    override fun onCreate() {
        super.onCreate()
        val db = AppDatabase.getInstance(this)
        repository = PetRepository(db)
    }
}
