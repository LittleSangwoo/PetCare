package com.vetpocket.app.data.db

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverter
import androidx.room.TypeConverters
import com.vetpocket.app.data.db.dao.DiaryNoteDao
import com.vetpocket.app.data.db.dao.MedicalEventDao
import com.vetpocket.app.data.db.dao.PetProfileDao
import com.vetpocket.app.data.db.dao.WeightRecordDao
import com.vetpocket.app.data.db.entities.DiaryNoteEntity
import com.vetpocket.app.data.db.entities.MedicalEventEntity
import com.vetpocket.app.data.db.entities.MedicalEventType
import com.vetpocket.app.data.db.entities.PetProfileEntity
import com.vetpocket.app.data.db.entities.WeightRecordEntity

class Converters {
    @TypeConverter
    fun fromEventType(type: MedicalEventType): String = type.name

    @TypeConverter
    fun toEventType(value: String): MedicalEventType = MedicalEventType.valueOf(value)
}

@Database(
    entities = [
        PetProfileEntity::class,
        WeightRecordEntity::class,
        MedicalEventEntity::class,
        DiaryNoteEntity::class
    ],
    version = 1,
    exportSchema = false
)
@TypeConverters(Converters::class)
abstract class AppDatabase : RoomDatabase() {
    abstract fun petProfileDao(): PetProfileDao
    abstract fun weightRecordDao(): WeightRecordDao
    abstract fun medicalEventDao(): MedicalEventDao
    abstract fun diaryNoteDao(): DiaryNoteDao

    companion object {
        @Volatile private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase =
            INSTANCE ?: synchronized(this) {
                INSTANCE ?: Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "vetpocket.db"
                ).build().also { INSTANCE = it }
            }
    }
}
