package com.vetpocket.app.data.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.vetpocket.app.data.db.entities.DiaryNoteEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface DiaryNoteDao {
    @Query("SELECT * FROM diary_note WHERE petId = :petId ORDER BY timestamp DESC")
    fun observeForPet(petId: Long): Flow<List<DiaryNoteEntity>>

    @Insert
    suspend fun insert(note: DiaryNoteEntity): Long
}
