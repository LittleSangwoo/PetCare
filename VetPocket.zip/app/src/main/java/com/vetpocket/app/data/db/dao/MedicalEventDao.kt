package com.vetpocket.app.data.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.vetpocket.app.data.db.entities.MedicalEventEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface MedicalEventDao {
    @Query("SELECT * FROM medical_event WHERE petId = :petId ORDER BY eventDate DESC")
    fun observeForPet(petId: Long): Flow<List<MedicalEventEntity>>

    @Query("""
        SELECT * FROM medical_event
        WHERE isScheduledReminder = 1
        ORDER BY eventDate ASC
    """)
    suspend fun getAllScheduledReminders(): List<MedicalEventEntity>

    @Insert
    suspend fun insert(event: MedicalEventEntity): Long
}
