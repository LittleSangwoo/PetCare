package com.vetpocket.app.data.db.dao

import androidx.room.*
import com.vetpocket.app.data.db.entities.PetProfileEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface PetProfileDao {
    @Query("SELECT * FROM pet_profile LIMIT 1")
    fun observePrimaryPet(): Flow<PetProfileEntity?>

    @Query("SELECT * FROM pet_profile WHERE id = :petId")
    suspend fun getById(petId: Long): PetProfileEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun upsert(pet: PetProfileEntity): Long

    @Update
    suspend fun update(pet: PetProfileEntity)
}
