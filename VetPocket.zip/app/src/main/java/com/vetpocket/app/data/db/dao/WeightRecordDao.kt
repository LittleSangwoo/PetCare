package com.vetpocket.app.data.db.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import com.vetpocket.app.data.db.entities.WeightRecordEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface WeightRecordDao {
    @Query("SELECT * FROM weight_record WHERE petId = :petId ORDER BY timestamp ASC")
    fun observeForPet(petId: Long): Flow<List<WeightRecordEntity>>

    @Query("SELECT * FROM weight_record WHERE petId = :petId ORDER BY timestamp DESC LIMIT 1")
    suspend fun getLatest(petId: Long): WeightRecordEntity?

    @Insert
    suspend fun insert(record: WeightRecordEntity): Long
}
