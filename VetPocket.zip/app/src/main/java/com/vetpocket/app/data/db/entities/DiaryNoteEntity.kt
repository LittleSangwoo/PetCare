package com.vetpocket.app.data.db.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

/** Заметка хроники/дневника (вкладка 3), например "Вялый" или "Срыгнул шерстью". */
@Entity(tableName = "diary_note")
data class DiaryNoteEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val petId: Long,
    val timestamp: Long,
    val symptomText: String,
    val tags: String = "" // опциональные теги состояния, через запятую
)
