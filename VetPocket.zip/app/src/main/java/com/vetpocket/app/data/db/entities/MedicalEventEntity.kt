package com.vetpocket.app.data.db.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

enum class MedicalEventType {
    VACCINATION_COMPLEX,  // Комплексная вакцина
    VACCINATION_RABIES,   // Бешенство
    TREATMENT_TICKS,      // От клещей
    TREATMENT_WORMS       // От гельминтов
}

/**
 * Событие в медкарте (вкладка 1). Если isScheduledReminder = true — данные
 * передаются в AlarmManager (см. data/reminder/ReminderScheduler.kt) для
 * планирования локального пуш-уведомления через reminderIntervalDays.
 */
@Entity(tableName = "medical_event")
data class MedicalEventEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val petId: Long,
    val type: MedicalEventType,
    val drugName: String,
    val eventDate: Long,           // дата проведения, epoch millis
    val isScheduledReminder: Boolean,
    val reminderIntervalDays: Int? = null // например 90 (3 месяца) или 365 (год)
)
