package com.vetpocket.app.data.db.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Профиль питомца. chronicConditions напрямую подставляется в System Prompt
 * при обращении к LLM (см. data/llm/PromptBuilder.kt).
 */
@Entity(tableName = "pet_profile")
data class PetProfileEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val birthDate: Long,          // epoch millis
    val isNeutered: Boolean,
    val breed: String,
    val chronicConditions: String, // например "МКБ"
    val photoUri: String? = null
)
