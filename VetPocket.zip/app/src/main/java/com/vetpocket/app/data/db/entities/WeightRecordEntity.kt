package com.vetpocket.app.data.db.entities

import androidx.room.Entity
import androidx.room.PrimaryKey

/** Хранит историю измерений веса. Используется для графика Vico (вкладка 2). */
@Entity(tableName = "weight_record")
data class WeightRecordEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val petId: Long,
    val timestamp: Long,
    val weightValue: Float // кг
)
