package com.vetpocket.app.data.llm

import com.vetpocket.app.BuildConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

sealed class FoodVerdict {
    data class Result(
        val verdict: Verdict,
        val summary: String
    ) : FoodVerdict()

    data class Error(val message: String) : FoodVerdict()

    enum class Verdict { GOOD, CAUTION, NOT_RECOMMENDED }
}

/**
 * Клиент для обращения к LLM API (см. Экран 2 — "Анализатор корма").
 * System Prompt формируется динамически через PromptBuilder на основе
 * профиля питомца, а не отправляется как абстрактный текст.
 */
class LlmClient(
    private val apiKey: String,
    private val client: OkHttpClient = OkHttpClient.Builder()
        .connectTimeout(30, TimeUnit.SECONDS)
        .readTimeout(60, TimeUnit.SECONDS)
        .build()
) {
    private val jsonMediaType = "application/json".toMediaType()

    suspend fun analyzeFood(systemPrompt: String, userPrompt: String): FoodVerdict =
        withContext(Dispatchers.IO) {
            try {
                val body = JSONObject().apply {
                    put("model", "claude-sonnet-4-6")
                    put("max_tokens", 800)
                    put("system", systemPrompt)
                    put("messages", JSONArray().put(
                        JSONObject().apply {
                            put("role", "user")
                            put("content", userPrompt)
                        }
                    ))
                }

                val request = Request.Builder()
                    .url(BuildConfig.LLM_API_BASE_URL)
                    .addHeader("x-api-key", apiKey)
                    .addHeader("anthropic-version", "2023-06-01")
                    .post(body.toString().toRequestBody(jsonMediaType))
                    .build()

                client.newCall(request).execute().use { response ->
                    if (!response.isSuccessful) {
                        return@withContext FoodVerdict.Error("Ошибка сети: ${response.code}")
                    }
                    val text = parseResponseText(response.body?.string().orEmpty())
                    parseVerdict(text)
                }
            } catch (e: Exception) {
                FoodVerdict.Error(e.message ?: "Неизвестная ошибка")
            }
        }

    private fun parseResponseText(raw: String): String {
        val json = JSONObject(raw)
        val content = json.optJSONArray("content") ?: return ""
        val sb = StringBuilder()
        for (i in 0 until content.length()) {
            val block = content.getJSONObject(i)
            if (block.optString("type") == "text") sb.append(block.optString("text"))
        }
        return sb.toString()
    }

    private fun parseVerdict(text: String): FoodVerdict.Result {
        val verdict = when {
            text.contains("🔴") || text.contains("не рекомендуется", ignoreCase = true) ->
                FoodVerdict.Verdict.NOT_RECOMMENDED
            text.contains("🟡") || text.contains("с осторожностью", ignoreCase = true) ->
                FoodVerdict.Verdict.CAUTION
            else -> FoodVerdict.Verdict.GOOD
        }
        return FoodVerdict.Result(verdict = verdict, summary = text)
    }
}
