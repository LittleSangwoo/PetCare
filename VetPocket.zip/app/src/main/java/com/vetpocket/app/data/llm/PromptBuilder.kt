package com.vetpocket.app.data.llm

import com.vetpocket.app.data.db.entities.PetProfileEntity
import java.util.concurrent.TimeUnit

/**
 * Строит System Prompt на основе данных из Room (см. раздел 3 документации:
 * "Интеграция искусственного интеллекта"), а не отправляет распознанный текст
 * корма напрямую без контекста.
 */
object PromptBuilder {

    fun buildSystemPrompt(pet: PetProfileEntity): String {
        val ageYears = ageInYears(pet.birthDate)
        val neuterStatus = if (pet.isNeutered) "Кастрирован" else "Не кастрирован"
        val conditions = pet.chronicConditions.ifBlank { "нет" }

        return """
            Ты профессиональный ветеринар-диетолог. Проанализируй состав корма для кота.
            Профиль животного: Имя: ${pet.name}, $ageYears лет, $neuterStatus.
            Порода: ${pet.breed}. Хронические заболевания: $conditions.
            Оцени ингредиенты, выдели плюсы и минусы, и дай итоговый вердикт
            о применимости этого корма конкретно для этого животного.
            Обрати особое внимание на компоненты, критичные при указанных
            хронических заболеваниях (например, уровень магния и фосфора при риске МКБ).
        """.trimIndent()
    }

    fun buildUserPrompt(recognizedIngredientsText: String): String =
        "Состав корма (распознан со снимка упаковки):\n$recognizedIngredientsText"

    private fun ageInYears(birthDateMillis: Long): Int {
        val diff = System.currentTimeMillis() - birthDateMillis
        return TimeUnit.MILLISECONDS.toDays(diff).toInt() / 365
    }
}
