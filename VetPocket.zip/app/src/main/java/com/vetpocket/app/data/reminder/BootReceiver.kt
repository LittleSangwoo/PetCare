package com.vetpocket.app.data.reminder

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import com.vetpocket.app.data.db.AppDatabase
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

/** После перезагрузки устройства заново регистрирует все отложенные напоминания. */
class BootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return

        val db = AppDatabase.getInstance(context)
        val scheduler = ReminderScheduler(context)

        CoroutineScope(Dispatchers.IO).launch {
            db.medicalEventDao().getAllScheduledReminders().forEach { event ->
                scheduler.schedule(event)
            }
        }
    }
}
