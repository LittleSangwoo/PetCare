package com.vetpocket.app.data.reminder

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import androidx.core.app.NotificationCompat
import com.vetpocket.app.MainActivity
import com.vetpocket.app.R

/** Показывает уведомление о приближающейся прививке/обработке. */
class ReminderReceiver : BroadcastReceiver() {

    companion object {
        const val EXTRA_EVENT_ID = "extra_event_id"
        const val EXTRA_DRUG_NAME = "extra_drug_name"
        const val EXTRA_EVENT_TYPE = "extra_event_type"
        private const val CHANNEL_ID = "vetpocket_reminders"
    }

    override fun onReceive(context: Context, intent: Intent) {
        val eventId = intent.getLongExtra(EXTRA_EVENT_ID, -1)
        val drugName = intent.getStringExtra(EXTRA_DRUG_NAME) ?: "Процедура"

        val manager = context.getSystemService(NotificationManager::class.java)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                CHANNEL_ID, "Напоминания о здоровье питомца",
                NotificationManager.IMPORTANCE_HIGH
            )
            manager?.createNotificationChannel(channel)
        }

        val openAppIntent = Intent(context, MainActivity::class.java)
        val contentIntent = PendingIntent.getActivity(
            context, eventId.toInt(), openAppIntent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        val notification = NotificationCompat.Builder(context, CHANNEL_ID)
            .setSmallIcon(R.drawable.ic_notification)
            .setContentTitle("Пора напомнить")
            .setContentText("Следующая процедура: $drugName")
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setContentIntent(contentIntent)
            .setAutoCancel(true)
            .build()

        manager?.notify(eventId.toInt(), notification)
    }
}
