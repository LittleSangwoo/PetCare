package com.vetpocket.app.data.reminder

import android.app.AlarmManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import androidx.core.content.ContextCompat
import com.vetpocket.app.data.db.entities.MedicalEventEntity
import java.util.concurrent.TimeUnit

/**
 * Планирует локальные пуш-уведомления через AlarmManager для медицинских
 * событий с флагом isScheduledReminder (см. раздел 4, MedicalEventEntity).
 */
class ReminderScheduler(private val context: Context) {

    private val alarmManager = ContextCompat.getSystemService(context, AlarmManager::class.java)

    fun schedule(event: MedicalEventEntity) {
        val intervalDays = event.reminderIntervalDays ?: return
        val triggerAt = event.eventDate + TimeUnit.DAYS.toMillis(intervalDays.toLong())

        val intent = Intent(context, ReminderReceiver::class.java).apply {
            putExtra(ReminderReceiver.EXTRA_EVENT_ID, event.id)
            putExtra(ReminderReceiver.EXTRA_DRUG_NAME, event.drugName)
            putExtra(ReminderReceiver.EXTRA_EVENT_TYPE, event.type.name)
        }

        val pendingIntent = PendingIntent.getBroadcast(
            context,
            event.id.toInt(),
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )

        alarmManager?.setExactAndAllowWhileIdle(
            AlarmManager.RTC_WAKEUP,
            triggerAt,
            pendingIntent
        )
    }

    fun cancel(eventId: Long) {
        val intent = Intent(context, ReminderReceiver::class.java)
        val pendingIntent = PendingIntent.getBroadcast(
            context, eventId.toInt(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        alarmManager?.cancel(pendingIntent)
    }
}
