package com.vetpocket.app.data.repository

import com.vetpocket.app.data.db.AppDatabase
import com.vetpocket.app.data.db.entities.*
import kotlinx.coroutines.flow.Flow

/**
 * Единая точка доступа к данным Room для всех ViewModel'ей приложения.
 */
class PetRepository(private val db: AppDatabase) {

    // --- Профиль питомца ---
    fun observePrimaryPet(): Flow<PetProfileEntity?> = db.petProfileDao().observePrimaryPet()

    suspend fun savePet(pet: PetProfileEntity): Long = db.petProfileDao().upsert(pet)

    suspend fun getPet(petId: Long): PetProfileEntity? = db.petProfileDao().getById(petId)

    // --- Вес ---
    fun observeWeightHistory(petId: Long): Flow<List<WeightRecordEntity>> =
        db.weightRecordDao().observeForPet(petId)

    suspend fun addWeightRecord(petId: Long, weightKg: Float, timestamp: Long = System.currentTimeMillis()) {
        db.weightRecordDao().insert(WeightRecordEntity(petId = petId, timestamp = timestamp, weightValue = weightKg))
    }

    suspend fun getLatestWeight(petId: Long): WeightRecordEntity? = db.weightRecordDao().getLatest(petId)

    // --- Медицинские события ---
    fun observeMedicalEvents(petId: Long): Flow<List<MedicalEventEntity>> =
        db.medicalEventDao().observeForPet(petId)

    suspend fun addMedicalEvent(event: MedicalEventEntity): Long = db.medicalEventDao().insert(event)

    suspend fun getAllScheduledReminders(): List<MedicalEventEntity> =
        db.medicalEventDao().getAllScheduledReminders()

    // --- Дневник ---
    fun observeDiary(petId: Long): Flow<List<DiaryNoteEntity>> = db.diaryNoteDao().observeForPet(petId)

    suspend fun addDiaryNote(petId: Long, text: String, tags: String = "") {
        db.diaryNoteDao().insert(
            DiaryNoteEntity(petId = petId, timestamp = System.currentTimeMillis(), symptomText = text, tags = tags)
        )
    }
}
