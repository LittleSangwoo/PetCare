package com.vetpocket.app.navigation

import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Place
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import com.vetpocket.app.ui.dashboard.DashboardScreen
import com.vetpocket.app.ui.health.HealthScreen
import com.vetpocket.app.ui.map.MapScreen
import com.vetpocket.app.ui.scanner.ScannerScreen

/**
 * Четыре экрана, доступных через нижнее навигационное меню (см. раздел 2 документации).
 */
sealed class Screen(val route: String, val label: String, val icon: ImageVector) {
    data object Dashboard : Screen("dashboard", "Главная", Icons.Filled.Home)
    data object Scanner : Screen("scanner", "Сканер", Icons.Filled.CameraAlt)
    data object Health : Screen("health", "Медкарта", Icons.Filled.Favorite)
    data object Map : Screen("map", "Карта", Icons.Filled.Place)

    companion object {
        val bottomBarItems = listOf(Dashboard, Scanner, Health, Map)
    }
}

@androidx.compose.runtime.Composable
fun VetPocketNavHost(navController: NavHostController) {
    NavHost(navController = navController, startDestination = Screen.Dashboard.route) {
        composable(Screen.Dashboard.route) {
            DashboardScreen(onNavigateToMap = { navController.navigate(Screen.Map.route) })
        }
        composable(Screen.Scanner.route) { ScannerScreen() }
        composable(Screen.Health.route) { HealthScreen() }
        composable(Screen.Map.route) { MapScreen() }
    }
}
