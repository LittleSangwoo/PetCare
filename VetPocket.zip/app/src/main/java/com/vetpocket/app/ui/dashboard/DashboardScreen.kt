package com.vetpocket.app.ui.dashboard

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.vetpocket.app.VetPocketApp
import com.vetpocket.app.ui.components.SosButton

/**
 * Экран 1 — Главная (Dashboard): шапка профиля, виджет ближайших событий,
 * блок SOS и быстрое действие "+ Взвесить" (BottomSheet).
 */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DashboardScreen(onNavigateToMap: () -> Unit) {
    val context = LocalContext.current
    val app = context.applicationContext as VetPocketApp
    val viewModel: DashboardViewModel = viewModel(factory = DashboardViewModel.Factory(app.repository))
    val state by viewModel.uiState.collectAsState()

    var showWeightSheet by remember { mutableStateOf(false) }

    Scaffold(
        floatingActionButton = {
            ExtendedFloatingActionButton(
                text = { Text("Взвесить") },
                icon = { Icon(Icons.Filled.Add, contentDescription = null) },
                onClick = { showWeightSheet = true }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .padding(16.dp)
                .fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            ProfileHeader(
                name = state.pet?.name ?: "Питомец не добавлен",
                weight = state.currentWeight
            )

            SosButton(onClick = onNavigateToMap)

            Text("Ближайшие события", style = MaterialTheme.typography.titleMedium)
            if (state.upcomingEvents.isEmpty()) {
                Text(
                    "Запланированных напоминаний пока нет",
                    style = MaterialTheme.typography.bodyMedium,
                    color = Color.Gray
                )
            } else {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    items(state.upcomingEvents) { event ->
                        EventCard(label = event.label, daysUntil = event.daysUntil)
                    }
                }
            }
        }
    }

    if (showWeightSheet) {
        WeightBottomSheet(
            onDismiss = { showWeightSheet = false },
            onConfirm = { weight ->
                viewModel.addWeight(weight)
                showWeightSheet = false
                Toast.makeText(context, "Вес сохранён", Toast.LENGTH_SHORT).show()
            }
        )
    }
}

@Composable
private fun ProfileHeader(name: String, weight: Float?) {
    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(12.dp)) {
        Box(
            Modifier
                .size(64.dp)
                .clip(CircleShape)
                .background(MaterialTheme.colorScheme.primaryContainer)
        )
        Column {
            Text(name, style = MaterialTheme.typography.titleLarge)
            Text(
                weight?.let { "Текущий вес: %.1f кг".format(it) } ?: "Вес ещё не указан",
                style = MaterialTheme.typography.bodyMedium
            )
        }
    }
}

@Composable
private fun EventCard(label: String, daysUntil: Long) {
    val description = when {
        daysUntil < 0 -> "Просрочено"
        daysUntil == 0L -> "Сегодня"
        else -> "через $daysUntil дн."
    }
    Card(shape = RoundedCornerShape(12.dp)) {
        Column(Modifier.padding(12.dp)) {
            Text(label, style = MaterialTheme.typography.titleSmall)
            Text(description, style = MaterialTheme.typography.bodyMedium)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun WeightBottomSheet(onDismiss: () -> Unit, onConfirm: (Float) -> Unit) {
    var input by remember { mutableStateOf("") }

    ModalBottomSheet(onDismissRequest = onDismiss) {
        Column(Modifier.padding(24.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Text("Новое значение веса (кг)", style = MaterialTheme.typography.titleMedium)
            OutlinedTextField(
                value = input,
                onValueChange = { input = it },
                singleLine = true,
                label = { Text("Вес, кг") }
            )
            Button(
                onClick = { input.toFloatOrNull()?.let(onConfirm) },
                enabled = input.toFloatOrNull() != null,
                modifier = Modifier.fillMaxWidth()
            ) { Text("Сохранить") }
        }
    }
}
