package com.vetpocket.app.ui.dashboard

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.vetpocket.app.data.db.entities.MedicalEventEntity
import com.vetpocket.app.data.db.entities.PetProfileEntity
import com.vetpocket.app.data.db.entities.WeightRecordEntity
import com.vetpocket.app.data.repository.PetRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import java.util.concurrent.TimeUnit

data class UpcomingEvent(val label: String, val daysUntil: Long)

data class DashboardUiState(
    val pet: PetProfileEntity? = null,
    val currentWeight: Float? = null,
    val upcomingEvents: List<UpcomingEvent> = emptyList()
)

class DashboardViewModel(private val repository: PetRepository) : ViewModel() {

    val uiState: StateFlow<DashboardUiState> = repository.observePrimaryPet()
        .flatMapLatest { pet ->
            if (pet == null) {
                flowOf(DashboardUiState())
            } else {
                combine(
                    repository.observeWeightHistory(pet.id),
                    repository.observeMedicalEvents(pet.id)
                ) { weights, events ->
                    DashboardUiState(
                        pet = pet,
                        currentWeight = weights.lastOrNull()?.weightValue,
                        upcomingEvents = events
                            .filter { it.isScheduledReminder && it.reminderIntervalDays != null }
                            .map { toUpcomingEvent(it) }
                            .sortedBy { it.daysUntil }
                    )
                }
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), DashboardUiState())

    fun addWeight(weightKg: Float) {
        val pet = uiState.value.pet ?: return
        viewModelScope.launch { repository.addWeightRecord(pet.id, weightKg) }
    }

    private fun toUpcomingEvent(event: MedicalEventEntity): UpcomingEvent {
        val dueDate = event.eventDate + TimeUnit.DAYS.toMillis(event.reminderIntervalDays!!.toLong())
        val daysUntil = TimeUnit.MILLISECONDS.toDays(dueDate - System.currentTimeMillis())
        return UpcomingEvent(label = event.drugName, daysUntil = daysUntil)
    }

    class Factory(private val repository: PetRepository) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
            DashboardViewModel(repository) as T
    }
}
