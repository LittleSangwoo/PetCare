package com.vetpocket.app.ui.health

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.vetpocket.app.data.db.entities.DiaryNoteEntity
import java.text.SimpleDateFormat
import java.util.*

private val dateFormat = SimpleDateFormat("dd.MM.yyyy HH:mm", Locale.getDefault())

/**
 * Вкладка 3 — Хроника/Дневник. Список текстовых заметок с привязкой к датам
 * для фиксации симптомов, например "Вялый" или "Срыгнул шерстью".
 */
@Composable
fun DiaryTab(notes: List<DiaryNoteEntity>, onAdd: (String, String) -> Unit) {
    var showDialog by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(notes) { note ->
                Card {
                    Column(Modifier.padding(12.dp)) {
                        Text(note.symptomText, style = MaterialTheme.typography.bodyLarge)
                        Text(dateFormat.format(Date(note.timestamp)), style = MaterialTheme.typography.bodySmall)
                        if (note.tags.isNotBlank()) {
                            Text(note.tags, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }

        FloatingActionButton(
            onClick = { showDialog = true },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
        ) { Text("+") }
    }

    if (showDialog) {
        AddDiaryNoteDialog(
            onDismiss = { showDialog = false },
            onConfirm = { text, tags -> onAdd(text, tags); showDialog = false }
        )
    }
}

@Composable
private fun AddDiaryNoteDialog(onDismiss: () -> Unit, onConfirm: (String, String) -> Unit) {
    var text by remember { mutableStateOf("") }
    var tags by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Новая заметка") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                OutlinedTextField(
                    value = text,
                    onValueChange = { text = it },
                    label = { Text("Например: Вялый") }
                )
                OutlinedTextField(
                    value = tags,
                    onValueChange = { tags = it },
                    label = { Text("Теги (через запятую)") }
                )
            }
        },
        confirmButton = {
            TextButton(onClick = { onConfirm(text, tags) }, enabled = text.isNotBlank()) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}
