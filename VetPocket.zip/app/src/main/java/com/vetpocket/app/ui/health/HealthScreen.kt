package com.vetpocket.app.ui.health

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.lifecycle.viewmodel.compose.viewModel
import com.vetpocket.app.VetPocketApp
import com.vetpocket.app.data.reminder.ReminderScheduler

private val tabs = listOf("Прививки и обработки", "График веса", "Хроника")

/** Экран 3 — Медкарта: три вкладки (Tabs). */
@Composable
fun HealthScreen() {
    val context = LocalContext.current
    val app = context.applicationContext as VetPocketApp
    val reminderScheduler = remember { ReminderScheduler(context) }
    val viewModel: HealthViewModel = viewModel(
        factory = HealthViewModel.Factory(app.repository, reminderScheduler)
    )
    val state by viewModel.uiState.collectAsState()

    var selectedTab by remember { mutableStateOf(0) }

    Column(Modifier.fillMaxSize()) {
        TabRow(selectedTabIndex = selectedTab) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = selectedTab == index,
                    onClick = { selectedTab = index },
                    text = { Text(title) }
                )
            }
        }

        when (selectedTab) {
            0 -> VaccinationsTab(
                events = state.medicalEvents,
                onAdd = viewModel::addMedicalEvent
            )
            1 -> WeightChartTab(records = state.weightHistory)
            2 -> DiaryTab(
                notes = state.diaryNotes,
                onAdd = viewModel::addDiaryNote
            )
        }
    }
}
