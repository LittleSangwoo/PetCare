package com.vetpocket.app.ui.health

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.vetpocket.app.data.db.entities.*
import com.vetpocket.app.data.reminder.ReminderScheduler
import com.vetpocket.app.data.repository.PetRepository
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

data class HealthUiState(
    val petId: Long? = null,
    val medicalEvents: List<MedicalEventEntity> = emptyList(),
    val weightHistory: List<WeightRecordEntity> = emptyList(),
    val diaryNotes: List<DiaryNoteEntity> = emptyList()
)

/** ViewModel для экрана 3 — Медкарта (три вкладки). */
class HealthViewModel(
    private val repository: PetRepository,
    private val reminderScheduler: ReminderScheduler
) : ViewModel() {

    val uiState: StateFlow<HealthUiState> = repository.observePrimaryPet()
        .flatMapLatest { pet ->
            if (pet == null) flowOf(HealthUiState())
            else combine(
                repository.observeMedicalEvents(pet.id),
                repository.observeWeightHistory(pet.id),
                repository.observeDiary(pet.id)
            ) { events, weights, diary ->
                HealthUiState(pet.id, events, weights, diary)
            }
        }
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), HealthUiState())

    fun addMedicalEvent(
        type: MedicalEventType,
        drugName: String,
        eventDate: Long,
        remind: Boolean,
        intervalDays: Int?
    ) {
        val petId = uiState.value.petId ?: return
        viewModelScope.launch {
            val id = repository.addMedicalEvent(
                MedicalEventEntity(
                    petId = petId,
                    type = type,
                    drugName = drugName,
                    eventDate = eventDate,
                    isScheduledReminder = remind,
                    reminderIntervalDays = intervalDays
                )
            )
            if (remind && intervalDays != null) {
                reminderScheduler.schedule(
                    MedicalEventEntity(id, petId, type, drugName, eventDate, true, intervalDays)
                )
            }
        }
    }

    fun addDiaryNote(text: String, tags: String) {
        val petId = uiState.value.petId ?: return
        viewModelScope.launch { repository.addDiaryNote(petId, text, tags) }
    }

    class Factory(
        private val repository: PetRepository,
        private val reminderScheduler: ReminderScheduler
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
            HealthViewModel(repository, reminderScheduler) as T
    }
}
