package com.vetpocket.app.ui.health

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.vetpocket.app.data.db.entities.MedicalEventEntity
import com.vetpocket.app.data.db.entities.MedicalEventType
import java.text.SimpleDateFormat
import java.util.*

private val dateFormat = SimpleDateFormat("dd.MM.yyyy", Locale.getDefault())

private fun typeLabel(type: MedicalEventType) = when (type) {
    MedicalEventType.VACCINATION_COMPLEX -> "Комплексная вакцина"
    MedicalEventType.VACCINATION_RABIES -> "Бешенство"
    MedicalEventType.TREATMENT_TICKS -> "От клещей"
    MedicalEventType.TREATMENT_WORMS -> "От гельминтов"
}

/**
 * Вкладка 1 — Прививки и обработки. Ручное добавление записи: тип процедуры,
 * название препарата, дата, чекбокс "Напомнить о следующей" с селектором интервала.
 */
@Composable
fun VaccinationsTab(
    events: List<MedicalEventEntity>,
    onAdd: (MedicalEventType, String, Long, Boolean, Int?) -> Unit
) {
    var showDialog by remember { mutableStateOf(false) }

    Box(Modifier.fillMaxSize()) {
        LazyColumn(
            Modifier.fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(events) { event ->
                Card {
                    Column(Modifier.padding(12.dp)) {
                        Text(typeLabel(event.type), style = MaterialTheme.typography.titleSmall)
                        Text(event.drugName, style = MaterialTheme.typography.bodyMedium)
                        Text(dateFormat.format(Date(event.eventDate)), style = MaterialTheme.typography.bodySmall)
                        if (event.isScheduledReminder) {
                            Text(
                                "Напоминание через ${event.reminderIntervalDays} дн.",
                                style = MaterialTheme.typography.labelSmall
                            )
                        }
                    }
                }
            }
        }

        FloatingActionButton(
            onClick = { showDialog = true },
            modifier = Modifier.align(Alignment.BottomEnd).padding(16.dp)
        ) { Text("+") }
    }

    if (showDialog) {
        AddMedicalEventDialog(
            onDismiss = { showDialog = false },
            onConfirm = { type, drug, date, remind, interval ->
                onAdd(type, drug, date, remind, interval)
                showDialog = false
            }
        )
    }
}

@Composable
private fun AddMedicalEventDialog(
    onDismiss: () -> Unit,
    onConfirm: (MedicalEventType, String, Long, Boolean, Int?) -> Unit
) {
    var type by remember { mutableStateOf(MedicalEventType.VACCINATION_COMPLEX) }
    var drugName by remember { mutableStateOf("") }
    var remind by remember { mutableStateOf(false) }
    var intervalDays by remember { mutableStateOf(90) } // например через 3 месяца
    var typeMenuExpanded by remember { mutableStateOf(false) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Новая запись") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                ExposedDropdownMenuBox(
                    expanded = typeMenuExpanded,
                    onExpandedChange = { typeMenuExpanded = it }
                ) {
                    OutlinedTextField(
                        value = typeLabel(type),
                        onValueChange = {},
                        readOnly = true,
                        label = { Text("Тип процедуры") },
                        modifier = Modifier.menuAnchor()
                    )
                    ExposedDropdownMenu(
                        expanded = typeMenuExpanded,
                        onDismissRequest = { typeMenuExpanded = false }
                    ) {
                        MedicalEventType.entries.forEach { option ->
                            DropdownMenuItem(
                                text = { Text(typeLabel(option)) },
                                onClick = { type = option; typeMenuExpanded = false }
                            )
                        }
                    }
                }

                OutlinedTextField(
                    value = drugName,
                    onValueChange = { drugName = it },
                    label = { Text("Название препарата") }
                )

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = remind, onCheckedChange = { remind = it })
                    Text("Напомнить о следующей")
                }

                if (remind) {
                    OutlinedTextField(
                        value = intervalDays.toString(),
                        onValueChange = { intervalDays = it.toIntOrNull() ?: intervalDays },
                        label = { Text("Через сколько дней (напр. 90 или 365)") }
                    )
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    onConfirm(type, drugName, System.currentTimeMillis(), remind, if (remind) intervalDays else null)
                },
                enabled = drugName.isNotBlank()
            ) { Text("Сохранить") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Отмена") } }
    )
}
