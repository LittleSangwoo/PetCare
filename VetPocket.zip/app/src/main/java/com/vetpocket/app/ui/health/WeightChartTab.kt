package com.vetpocket.app.ui.health

import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.patrykandpatrick.vico.compose.chart.Chart
import com.patrykandpatrick.vico.compose.chart.line.lineChart
import com.patrykandpatrick.vico.core.entry.ChartEntryModelProducer
import com.patrykandpatrick.vico.core.entry.entryOf
import com.vetpocket.app.data.db.entities.WeightRecordEntity

/**
 * Вкладка 2 — График веса. Линейный график изменения веса — важнейший
 * индикатор здоровья кота. Отрисован через библиотеку Vico для Compose.
 */
@Composable
fun WeightChartTab(records: List<WeightRecordEntity>) {
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Динамика веса", style = MaterialTheme.typography.titleMedium)

        if (records.isEmpty()) {
            Text(
                "Пока нет записей. Добавьте вес на главном экране.",
                style = MaterialTheme.typography.bodyMedium
            )
            return@Column
        }

        val entryProducer = remember(records) {
            ChartEntryModelProducer(
                records.mapIndexed { index, record -> entryOf(index.toFloat(), record.weightValue) }
            )
        }

        Chart(
            chart = lineChart(),
            chartModelProducer = entryProducer,
            modifier = Modifier.fillMaxSize()
        )
    }
}
