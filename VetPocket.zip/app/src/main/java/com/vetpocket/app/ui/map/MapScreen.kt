package com.vetpocket.app.ui.map

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState
import com.vetpocket.app.BuildConfig
import com.yandex.mapkit.MapKitFactory
import com.yandex.mapkit.geometry.Point
import com.yandex.mapkit.map.CameraPosition
import com.yandex.mapkit.mapview.MapView
import com.yandex.mapkit.search.SearchFactory
import com.yandex.mapkit.search.SearchManagerType
import com.yandex.mapkit.search.SearchOptions
import com.yandex.mapkit.search.Response
import com.yandex.mapkit.search.Session

/**
 * Экран 4 — Карта (SOS & Vets). Модуль геолокации через Yandex MapKit:
 * отображение позиции, автоматический поиск ветклиник, фильтр "Открыто
 * прямо сейчас" и карточка клиники с маршрутом и звонком по клику на маркер.
 *
 * Требуется задать реальный ключ в BuildConfig.YANDEX_MAPKIT_API_KEY
 * (app/build.gradle.kts) — MapKitFactory.setApiKey(...) вызывается один раз
 * до первого использования, обычно в Application.onCreate().
 */
@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun MapScreen() {
    val context = LocalContext.current
    val viewModel: MapViewModel = viewModel()
    val state = viewModel.uiState

    val locationPermission = rememberPermissionState(android.Manifest.permission.ACCESS_FINE_LOCATION)

    LaunchedEffect(Unit) {
        if (!locationPermission.status.isGranted) {
            locationPermission.launchPermissionRequest()
        }
    }

    Box(Modifier.fillMaxSize()) {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                MapKitFactory.initialize(ctx)
                val mapView = MapView(ctx)
                mapView.map.move(
                    CameraPosition(Point(55.751244, 37.618423), 12f, 0f, 0f)
                )
                searchVetClinics(ctx, mapView, state.openNowOnly, viewModel)
                mapView
            },
            update = { mapView ->
                searchVetClinics(context, mapView, state.openNowOnly, viewModel)
            }
        )

        FilterChip(
            selected = state.openNowOnly,
            onClick = { viewModel.toggleOpenNowFilter(!state.openNowOnly) },
            label = { Text("Открыто прямо сейчас") },
            modifier = Modifier.align(Alignment.TopCenter).padding(16.dp)
        )

        state.selectedClinic?.let { clinic ->
            ClinicInfoCard(
                clinic = clinic,
                onDismiss = { viewModel.selectClinic(null) },
                modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp)
            )
        }
    }
}

private fun searchVetClinics(
    context: android.content.Context,
    mapView: MapView,
    openNowOnly: Boolean,
    viewModel: MapViewModel
) {
    val searchManager = SearchFactory.getInstance().createSearchManager(SearchManagerType.ONLINE)
    val searchOptions = SearchOptions().apply { resultPageSize = 32 }

    searchManager.submit(
        "Ветеринарные клиники",
        mapView.map.visibleRegion,
        searchOptions,
        object : Session.SearchListener {
            override fun onSearchResponse(response: Response) {
                val clinics = response.collection.children.mapNotNull { item ->
                    val obj = item.obj ?: return@mapNotNull null
                    val point = obj.geometry.firstOrNull()?.point ?: return@mapNotNull null
                    VetClinic(
                        id = obj.metadataContainer.toString(),
                        name = obj.name ?: "Ветклиника",
                        latitude = point.latitude,
                        longitude = point.longitude,
                        phone = "",
                        isOpenNow = true // реальный статус работы приходит из BusinessObjectMetadata.workingHours
                    )
                }
                viewModel.onClinicsLoaded(clinics)
            }

            override fun onSearchError(error: com.yandex.runtime.Error) { /* показать ошибку пользователю */ }
        }
    )
}

@Composable
private fun ClinicInfoCard(clinic: VetClinic, onDismiss: () -> Unit, modifier: Modifier = Modifier) {
    val context = LocalContext.current
    Card(modifier = modifier) {
        Column(Modifier.padding(16.dp)) {
            Text(clinic.name, style = MaterialTheme.typography.titleMedium)
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                Button(onClick = {
                    val uri = Uri.parse("geo:${clinic.latitude},${clinic.longitude}?q=${clinic.latitude},${clinic.longitude}(${clinic.name})")
                    context.startActivity(Intent(Intent.ACTION_VIEW, uri))
                }) { Text("Маршрут") }

                OutlinedButton(onClick = {
                    if (clinic.phone.isNotBlank()) {
                        context.startActivity(Intent(Intent.ACTION_DIAL, Uri.parse("tel:${clinic.phone}")))
                    }
                }) { Text("Позвонить") }

                TextButton(onClick = onDismiss) { Text("Закрыть") }
            }
        }
    }
}
