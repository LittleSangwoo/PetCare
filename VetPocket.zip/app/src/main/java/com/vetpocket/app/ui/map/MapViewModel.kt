package com.vetpocket.app.ui.map

import androidx.lifecycle.ViewModel

data class VetClinic(
    val id: String,
    val name: String,
    val latitude: Double,
    val longitude: Double,
    val phone: String,
    val isOpenNow: Boolean
)

data class MapUiState(
    val clinics: List<VetClinic> = emptyList(),
    val openNowOnly: Boolean = false,
    val selectedClinic: VetClinic? = null
) {
    val visibleClinics: List<VetClinic>
        get() = if (openNowOnly) clinics.filter { it.isOpenNow } else clinics
}

/**
 * Экран 4 — Карта (SOS & Vets). Поиск по категории "Ветеринарные клиники"
 * выполняется через Yandex MapKit Search API (см. MapScreen для интеграции
 * самого MapView — SearchManager инициализируется там же, так как требует
 * Context/Lifecycle нативного View).
 */
class MapViewModel : ViewModel() {

    var uiState by androidx.compose.runtime.mutableStateOf(MapUiState())
        private set

    fun onClinicsLoaded(clinics: List<VetClinic>) {
        uiState = uiState.copy(clinics = clinics)
    }

    fun toggleOpenNowFilter(enabled: Boolean) {
        uiState = uiState.copy(openNowOnly = enabled)
    }

    fun selectClinic(clinic: VetClinic?) {
        uiState = uiState.copy(selectedClinic = clinic)
    }
}
