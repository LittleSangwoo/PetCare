package com.vetpocket.app.ui.scanner

import android.graphics.BitmapFactory
import androidx.compose.foundation.border
import androidx.camera.core.ImageCapture
import androidx.camera.core.ImageCaptureException
import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.google.accompanist.permissions.ExperimentalPermissionsApi
import com.google.accompanist.permissions.isGranted
import com.google.accompanist.permissions.rememberPermissionState
import com.vetpocket.app.BuildConfig
import com.vetpocket.app.VetPocketApp
import com.vetpocket.app.data.db.entities.PetProfileEntity
import com.vetpocket.app.data.llm.FoodVerdict
import com.vetpocket.app.data.llm.LlmClient
import java.io.File

/**
 * Экран 2 — Анализатор корма. Видоискатель камеры с направляющей рамкой,
 * кнопка "Сфотографировать", экран проверки распознанного текста и
 * экран результата с цветовым вердиктом.
 */
@OptIn(ExperimentalPermissionsApi::class)
@Composable
fun ScannerScreen() {
    val context = LocalContext.current
    val app = context.applicationContext as VetPocketApp
    val pet by app.repository.observePrimaryPet().collectAsState(initial = null)

    val llmClient = remember { LlmClient(apiKey = "YOUR_API_KEY") }
    val viewModel: ScannerViewModel = viewModel(factory = ScannerViewModel.Factory(pet, llmClient))

    val cameraPermission = rememberPermissionState(android.Manifest.permission.CAMERA)

    Box(Modifier.fillMaxSize()) {
        when (val step = viewModel.step) {
            is ScannerStep.Camera -> {
                if (cameraPermission.status.isGranted) {
                    CameraCaptureContent(onImageCaptured = viewModel::onImageCaptured)
                } else {
                    PermissionRequestContent(onRequest = { cameraPermission.launchPermissionRequest() })
                }
            }
            is ScannerStep.ReviewText -> ReviewTextContent(
                initialText = step.recognizedText,
                onConfirm = viewModel::onTextConfirmed,
                onRetake = viewModel::reset
            )
            is ScannerStep.Analyzing -> LoadingContent()
            is ScannerStep.Result -> ResultContent(step.verdict, onScanAgain = viewModel::reset)
            is ScannerStep.Failed -> ErrorContent(step.message, onRetry = viewModel::reset)
        }
    }
}

@Composable
private fun CameraCaptureContent(onImageCaptured: (android.graphics.Bitmap) -> Unit) {
    val context = LocalContext.current
    val imageCapture = remember { ImageCapture.Builder().build() }

    Box(Modifier.fillMaxSize()) {
        CameraPreview(onImageCaptured = onImageCaptured, imageCapture = imageCapture)

        // Направляющая рамка для наведения на текст состава
        Box(
            Modifier
                .align(Alignment.Center)
                .fillMaxWidth(0.85f)
                .height(180.dp)
                .border(2.dp, androidx.compose.ui.graphics.Color.White)
        )

        FloatingActionButton(
            onClick = {
                val photoFile = File(context.cacheDir, "capture_${System.currentTimeMillis()}.jpg")
                val outputOptions = ImageCapture.OutputFileOptions.Builder(photoFile).build()
                imageCapture.takePicture(
                    outputOptions,
                    ContextCompat.getMainExecutor(context),
                    object : ImageCapture.OnImageSavedCallback {
                        override fun onImageSaved(output: ImageCapture.OutputFileResults) {
                            val bitmap = BitmapFactory.decodeFile(photoFile.absolutePath)
                            onImageCaptured(bitmap)
                        }
                        override fun onError(exception: ImageCaptureException) { /* показать ошибку пользователю */ }
                    }
                )
            },
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .padding(24.dp)
        ) {
            Icon(Icons.Filled.CameraAlt, contentDescription = "Сфотографировать")
        }
    }
}

@Composable
private fun PermissionRequestContent(onRequest: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Для сканирования состава нужен доступ к камере")
        Spacer(Modifier.height(12.dp))
        Button(onClick = onRequest) { Text("Разрешить") }
    }
}

@Composable
private fun ReviewTextContent(initialText: String, onConfirm: (String) -> Unit, onRetake: () -> Unit) {
    var text by remember { mutableStateOf(initialText) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("Проверьте распознанный текст перед анализом", style = MaterialTheme.typography.titleMedium)
        Spacer(Modifier.height(12.dp))
        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            modifier = Modifier.fillMaxWidth().weight(1f)
        )
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            OutlinedButton(onClick = onRetake, modifier = Modifier.weight(1f)) { Text("Переснять") }
            Button(onClick = { onConfirm(text) }, modifier = Modifier.weight(1f)) { Text("Анализировать") }
        }
    }
}

@Composable
private fun LoadingContent() {
    Column(
        Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        CircularProgressIndicator()
        Spacer(Modifier.height(12.dp))
        Text("Анализируем состав...")
    }
}

@Composable
private fun ResultContent(result: FoodVerdict.Result, onScanAgain: () -> Unit) {
    val (emoji, label) = when (result.verdict) {
        FoodVerdict.Verdict.GOOD -> "🟢" to "Отлично"
        FoodVerdict.Verdict.CAUTION -> "🟡" to "С осторожностью"
        FoodVerdict.Verdict.NOT_RECOMMENDED -> "🔴" to "Не рекомендуется"
    }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text("$emoji $label", style = MaterialTheme.typography.headlineSmall)
        Spacer(Modifier.height(12.dp))
        Text(result.summary, style = MaterialTheme.typography.bodyMedium)
        Spacer(Modifier.height(24.dp))
        Button(onClick = onScanAgain) { Text("Сканировать ещё раз") }
    }
}

@Composable
private fun ErrorContent(message: String, onRetry: () -> Unit) {
    Column(
        Modifier.fillMaxSize().padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("Ошибка: $message")
        Spacer(Modifier.height(12.dp))
        Button(onClick = onRetry) { Text("Попробовать снова") }
    }
}
