package com.vetpocket.app.ui.scanner

import android.graphics.Bitmap
import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import com.vetpocket.app.data.db.entities.PetProfileEntity
import com.vetpocket.app.data.llm.FoodVerdict
import com.vetpocket.app.data.llm.LlmClient
import com.vetpocket.app.data.llm.PromptBuilder
import kotlinx.coroutines.launch
import kotlinx.coroutines.suspendCancellableCoroutine
import kotlin.coroutines.resume

sealed class ScannerStep {
    data object Camera : ScannerStep()
    data class ReviewText(val recognizedText: String) : ScannerStep()
    data object Analyzing : ScannerStep()
    data class Result(val verdict: FoodVerdict.Result) : ScannerStep()
    data class Failed(val message: String) : ScannerStep()
}

/**
 * Экран 2 — Анализатор корма. Процесс: захват кадра → ML Kit извлекает текст
 * локально (без сети) → ручное подтверждение пользователем → запрос к LLM
 * с System Prompt, построенным на основе профиля питомца.
 */
class ScannerViewModel(
    private val pet: PetProfileEntity?,
    private val llmClient: LlmClient
) : ViewModel() {

    var step by androidx.compose.runtime.mutableStateOf<ScannerStep>(ScannerStep.Camera)
        private set

    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    fun onImageCaptured(bitmap: Bitmap) {
        viewModelScope.launch {
            try {
                val text = recognizeText(bitmap)
                step = ScannerStep.ReviewText(text)
            } catch (e: Exception) {
                step = ScannerStep.Failed("Не удалось распознать текст: ${e.message}")
            }
        }
    }

    fun onTextConfirmed(editedText: String) {
        val currentPet = pet
        if (currentPet == null) {
            step = ScannerStep.Failed("Сначала заполните профиль питомца")
            return
        }
        viewModelScope.launch {
            step = ScannerStep.Analyzing
            val systemPrompt = PromptBuilder.buildSystemPrompt(currentPet)
            val userPrompt = PromptBuilder.buildUserPrompt(editedText)
            when (val result = llmClient.analyzeFood(systemPrompt, userPrompt)) {
                is FoodVerdict.Result -> step = ScannerStep.Result(result)
                is FoodVerdict.Error -> step = ScannerStep.Failed(result.message)
            }
        }
    }

    fun reset() {
        step = ScannerStep.Camera
    }

    private suspend fun recognizeText(bitmap: Bitmap): String =
        suspendCancellableCoroutine { cont ->
            val image = InputImage.fromBitmap(bitmap, 0)
            recognizer.process(image)
                .addOnSuccessListener { visionText -> cont.resume(visionText.text) }
                .addOnFailureListener { e -> cont.resume("") }
        }

    class Factory(
        private val pet: PetProfileEntity?,
        private val llmClient: LlmClient
    ) : ViewModelProvider.Factory {
        @Suppress("UNCHECKED_CAST")
        override fun <T : ViewModel> create(modelClass: Class<T>): T =
            ScannerViewModel(pet, llmClient) as T
    }
}
