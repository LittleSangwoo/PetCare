package com.vetpocket.app.ui.theme

import androidx.compose.ui.graphics.Color

val VetGreen = Color(0xFF2E7D32)
val VetYellow = Color(0xFFF9A825)
val VetRed = Color(0xFFC62828)
val VetPrimary = Color(0xFF00897B)
val VetBackground = Color(0xFFF5F7F7)
