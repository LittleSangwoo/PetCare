pluginManagement {
    repositories {
        google()
        mavenCentral()
        gradlePluginPortal()
    }
}
dependencyResolutionManagement {
    repositoriesMode.set(RepositoriesMode.FAIL_ON_PROJECT_REPOS)
    repositories {
        google()
        mavenCentral()
        // Репозиторий Yandex MapKit (нужен для экрана "Карта")
        maven { url = uri("https://maven.yandex.net/repository/maven") }
    }
}
rootProject.name = "VetPocket"
include(":app")
